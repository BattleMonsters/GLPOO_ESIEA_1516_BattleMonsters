package start;

import intgraphique.MenuIHM;

public class Lancher2 {

	public static void main(String[] args){
		MenuIHM jframe;
		jframe = new MenuIHM();
	}
	
}
