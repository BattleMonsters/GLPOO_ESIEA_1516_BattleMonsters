package start;

import pokemonCsv.Pokemon;
import pokemonCsv.SimplePokemon;
import spellsCsv.Spell;
import start.DefineTirage.Launch;
import start.DefineTirage.Quit;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Arrays;
import java.util.Random;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import intgraphique.FightGraph;


public class Combat extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static int displayTarget;
	
	public static boolean victory;
	public static int cible;
	public static int tour;
	public static int[] ciblelist = {8,8};
	public static int current;
	public static Pokemon attaquant;
	public static Spell spellChosen;
	public static int winner;
	public static int consoleID;
	
	public static String consoleAtt;
	
	public static Combat jeu;
	public static Pokemon[] listOrder;
	public static Pokemon monsPlaying;
	public FightGraph fightgraph;
	public static JFrame jframe;

	
	///---DEROULEMENT DU COMBAT---//
	
	public Combat fight2v2(Pokemon j1m1, Pokemon j1m2, Pokemon j2m1, Pokemon j2m2){
		displayTarget = 0;
		current = 0;
		tour = 1;
		listOrder = getSpeed(j1m1,j1m2,j2m1,j2m2);
		//System.out.println(""+listOrder[0]+listOrder[1]+listOrder[2]+listOrder[3]);
		
		jframe = new JFrame("Jeu");
		jframe.setVisible(true);
		jframe.setMinimumSize(new Dimension(1024,720));
		jframe.getContentPane().setLayout(new BorderLayout()); 
		jframe.setLocation(190,10);
		jframe.add(fightgraph = new FightGraph());
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		victory=false;
		startFight();
		
		return null;
	}
	
	public void startFight(){
		displayTarget=0; //Reset la variable d'affichage
		int cibleTemp=0;
		cible=8;
		
		if(current>=4){
			tour++;
			current = current-4;
		}
		
		consoleAtt = "Au tour de " +listOrder[current].getName() + " d'attaquer !" + " Joueur : "+listOrder[current].getDresseur();
		
		if(listOrder[current].getTourAffected()==tour){
			//System.out.println(listOrder[current].getName() + " nest plus " + listOrder[current].getStatus()+ " "+ tour);
			final SimplePokemon currenttemp =(SimplePokemon) listOrder[current];
			currenttemp.setStatus("null");
			currenttemp.setTourAffected(0);
			listOrder[current]=currenttemp;
		}
		
		attaquant = listOrder[current];
		fightgraph.repaint();
		
		if(attaquant.getHP()<=0){
			//System.out.println(attaquant.getName() + " est mort !!!");
			current++;
			startFight();
		}
		
		
		/* Application des effets que confère le status du pokémon */
		
		if(attaquant.getStatus().equals("PARA")){ // 50% de chance d'empecher le pokemon d'attaquer
			Random rand = new Random();
			if(rand.nextInt(100)+1 > 50){
				//System.out.println(attaquant.getName() + " est PARALYSE !!!");
				current++;
				startFight();
			}
		}
		if(attaquant.getStatus().equals("FEAR")){ // Empeche le pokemon d'attaquer
			current++;
			//System.out.println(attaquant.getName() + " est appeuré !!!");
			startFight();
		}
		if(attaquant.getStatus().equals("FROZEN")){ // 50% de chance d'empecher le pokemon d'attaquer
			Random rand = new Random();
			if(rand.nextInt(100)+1 > 50){
				current++;
				//System.out.println(attaquant.getName() + " est gelé !!!");
				startFight();
			}
		}
		if(attaquant.getReloading()==1){ // Le pokemon recharge son attaque
			//System.out.println(attaquant.getName() + " recharge !!!");
			final SimplePokemon reloadtemp =(SimplePokemon) listOrder[current];
			reloadtemp.setReloading(0);
			listOrder[current]=reloadtemp;
			current++;
			startFight();
		}
		if(attaquant.getStatus().equals("STUN")){ // Empecher le pokemon d'attaquer
			current++;
			//System.out.println(attaquant.getName() + " est étourdi !!!");
			startFight();
		}
		if(attaquant.getStatus().equals("BURN")){ // Le pokemon subit 50 points de dégats avant d'attaquer
			final SimplePokemon burningtemp =(SimplePokemon) listOrder[current];
			burningtemp.setHP(attaquant.getHP()-50);
			listOrder[current]=burningtemp;
			//System.out.println(attaquant.getName() + " est brulé !!!");
		}
		
		/* On récupère les cibles que le pokemon peut attaquer, il ne peut s'attaquer lui même ou un allié  */
			for(int j=0;j<4;j++){		
				if(listOrder[j].getDresseur() != listOrder[current].getDresseur() && listOrder[j].getHP()>0){
					ciblelist[cibleTemp]=j;
					cibleTemp++;
				}
				if(listOrder[j].getDresseur() != listOrder[current].getDresseur() && listOrder[j].getHP()<=0){
					ciblelist[cibleTemp]=8;
					cibleTemp++;
				}
			}
			
			if(ciblelist[0]==8 && ciblelist[1]==8){
				victory=true;
			}
			
			//System.out.println(attaquant.getName()+ " peut cibler " +ciblelist[0] + " ou " + ciblelist[1]);
			
			/* On recupere le choix de la cible */
			displayTarget=1;
			fightgraph.repaint();
			if(victory==true){
				jframe.addMouseListener(new MouseAdapter(){
					public void mouseClicked(MouseEvent e) {
							if((e.getX() >= 238 && e.getX() <= 419 ) && (e.getY() >= 617 && e.getY() <= 683)){
								jframe.removeMouseListener(this);
								jframe.dispose();
								try { 
									DefineTirage.buildContentPane();
								} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
							}
							if((e.getX() >= 636 && e.getX() <= 816 ) && (e.getY() >= 616 && e.getY() <= 685)){
								jframe.removeMouseListener(this);
								jframe.dispose();
							}
						}
					
				});
				}else{
			jframe.addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e) {
					if(displayTarget==1){
						if((e.getX() >= 40 && e.getX() <= 512 ) && (e.getY() >= 570 && e.getY() <= 720) && ciblelist[0]!=8){
							cible=0;
							jframe.removeMouseListener(this);
							getSpell();
						}
						if((e.getX() >= 512 && e.getX() <= 964 ) && (e.getY() >= 570 && e.getY() <= 720 && ciblelist[1]!=8)){
							cible=1;
							jframe.removeMouseListener(this);
							getSpell();
						}
					}
				}
			});
			}	
		}
	
	
	/* On recupere le choix de l'attaque lancée */
	public void getSpell(){	
		displayTarget=2;
		fightgraph.repaint();
		jframe.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				if(displayTarget==2){
				if((e.getX() >= 40 && e.getX() <= 224 ) && (e.getY() >= 570 && e.getY() <= 720 && displayTarget==2)){
					consoleAtt = listOrder[current].getName() + " utilise " +  listOrder[current].getSpell1().getSpellName()+ " sur "+ listOrder[ciblelist[cible]].getName()+ " Joueur : "+listOrder[current].getDresseur();
					jframe.removeMouseListener(this);
					castSpell(1);
				}
				if((e.getX() >= 224 && e.getX() <= 408 ) && (e.getY() >= 570 && e.getY() <= 720 && displayTarget==2)){
					consoleAtt = listOrder[current].getName() + " utilise " + listOrder[current].getSpell2().getSpellName()+ " sur "+ listOrder[ciblelist[cible]].getName()+ " Joueur : "+listOrder[current].getDresseur();
					jframe.removeMouseListener(this);
					castSpell(2);
				}	
				if((e.getX() >= 408 && e.getX() <= 592 ) && (e.getY() >= 570 && e.getY() <= 720 && displayTarget==2)){
					consoleAtt = listOrder[current].getName() + " utilise " + listOrder[current].getSpell3().getSpellName()+ " sur "+ listOrder[ciblelist[cible]].getName()+ " Joueur : "+listOrder[current].getDresseur();
					jframe.removeMouseListener(this);
					castSpell(3);
				}
				if((e.getX() >= 592 && e.getX() <= 776 ) && (e.getY() >= 570 && e.getY() <= 720 && displayTarget==2)){
					consoleAtt = listOrder[current].getName() + " utilise " + listOrder[current].getSpell4().getSpellName()+ " sur "+ listOrder[ciblelist[cible]].getName()+ " Joueur : "+listOrder[current].getDresseur();
					jframe.removeMouseListener(this);
					castSpell(4);
				}
				if((e.getX() >= 776 && e.getX() <= 984 ) && (e.getY() >= 570 && e.getY() <= 720 && displayTarget==2)){
					consoleAtt = listOrder[current].getName() + " utilise " + listOrder[current].getSpell5().getSpellName()+ " sur "+ listOrder[ciblelist[cible]].getName()+ " Joueur : "+listOrder[current].getDresseur();
					jframe.removeMouseListener(this);
					castSpell(5);
				}
			}
			}
	});
}
	
	
	
	/* ---Lancement du sort--- */
	private void castSpell(int spellInt){
		int dammages = 0;
		String effect = "null";
		int pourcent = 0;
				
		if(cible==8){
			startFight();
		}else{
			
		if(spellInt==1){
			spellChosen = listOrder[current].getSpell1();
		}
		if(spellInt==2){
			spellChosen = listOrder[current].getSpell2();
		}
		if(spellInt==3){
			spellChosen = listOrder[current].getSpell3();
			}
		if(spellInt==4){
			spellChosen = listOrder[current].getSpell4();
		}
		if(spellInt==5){
			spellChosen = listOrder[current].getSpell5();
			
		}
		
		dammages = spellChosen.getDammages();
		effect = spellChosen.getEffect();
		pourcent = spellChosen.getPourcent();
		
		//System.out.println("\nPokemon : "+listOrder[current].getName() +" attaque " + listOrder[ciblelist[cible]].getName()+ " avec  "+ spellChosen.getSpellName() +" et lui infliges " + dammages+ " dégats" );
		
		//Force/Faiblesse entre le sort et le pokemon qui recoit l'attaque
		int typeStrength = typeSpell(listOrder[ciblelist[cible]],spellChosen);
		if(typeStrength == 2){
			dammages=dammages+(dammages*50/100);
		}
		if(typeStrength == 0){
			dammages=dammages-(dammages*50/100);
		}
		
		int typeCaster = typeCaster(listOrder[current],spellChosen);
		if(typeCaster == 1){
			dammages=dammages+(dammages*50/100);
		}
		
		
		
		String status = listOrder[ciblelist[cible]].getStatus();
		int nbTourAffect = 0;
		
		/* Application des effets des sorts */
		if(effect != null && pourcent != 0){
			Random rand = new Random();
			if(rand.nextInt(100)+1 < pourcent){
				status = effect;
				
				if(status.equals("PARA")){
					nbTourAffect = tour+2;
				}
				if(status.equals("FROZEN") || status.equals("BURN")){
					nbTourAffect = tour+3;
				}
				if(status.equals("STUN") || status.equals("FEAR")){
					nbTourAffect = tour+1;
				}
				if(status.equals("CONFUSED")){
					nbTourAffect = tour+rand.nextInt(4)+1;
				}
				//System.out.println(listOrder[ciblelist[cible]].getName()+" est atteint de "+status+ " jusqu'au tour " + nbTourAffect);
			}
		}
		
		/* Le pokemon va devoir recharger au tour suivant */
		if(effect.equals("RELOAD")){
				final SimplePokemon currentreloadtemp =(SimplePokemon) listOrder[current];
				currentreloadtemp.setReloading(1);
				listOrder[current]=currentreloadtemp;
				//System.out.println(listOrder[current].getName()+" va devoir recharger");
		}
		
		/* Effet de Explosion, le pokemon perd tous ses pv et infliges 400 degats s'il a plus de 300pv, sinon 2x le nombre de ses hp restant */
		if(effect.equals("DIE")){
			if(listOrder[current].getHP()<200 && listOrder[current].getHP()>0){
				dammages=listOrder[current].getHP()*2; 
			}
			final SimplePokemon dietemp =(SimplePokemon) listOrder[current];
			dietemp.setHP(0);
			listOrder[current]=dietemp;
			//System.out.println(listOrder[current].getName()+" s'autodétruit");
	}
		int target;
		target = ciblelist[cible];
		
		/* Pokemon confus, il a 50% de chances de s'attaquer lui même */
		if(listOrder[current].getStatus().equals("CONFUSED")){
			Random rand1 = new Random();
			if(rand1.nextInt(100)+1 < 50){
				target = current;
				dammages = dammages*1/2;
				status = listOrder[current].getStatus();
				nbTourAffect = listOrder[current].getTourAffected();
			}
		}
		
		int currentHpTarget = listOrder[target].getHP();
		int hpTarget = currentHpTarget - dammages;
		
		final SimplePokemon targettemp =(SimplePokemon) listOrder[target];
		targettemp.setHP(hpTarget);
		targettemp.setStatus(status);
		targettemp.setTourAffected(nbTourAffect);
		listOrder[target]=targettemp;
		System.out.println("On change !!!!");
		
		current++;
		startFight();
		}
	}
	
	
	
	///---Si le type du pokemon est le meme que l'attaque envoyé, fera plus de degats---//
	
	private int typeCaster(Pokemon caster, Spell spellChosen) {
		if(caster.getType().equals(spellChosen.getSpellType())){
			return 1;
		}
		return 0;
	}


	
	/////---Si le type du spell est ennemi que le type du pokemon => + de degats, à l'inverse - de degats, sinon rien de change---//
	private int typeSpell(Pokemon target, Spell spellChosen) {
		//Cycle : Feu > Plante > Terre > Foudre > Eau > Feu
			int indicePokemon=0;	
			if(target.getType().equals("FIRE")){
				indicePokemon=1;
			}
			if(target.getType().equals("GRASS")){
				indicePokemon=2;
			}
			if(target.getType().equals("ROCK")){
				indicePokemon=3;
			}
			if(target.getType().equals("ELECTRIC")){
				indicePokemon=4;
			}
			if(target.getType().equals("WATER")){
				indicePokemon=5;
			}
			
			int indiceSpell=0;
			if(spellChosen.getSpellType().equals("FIRE")){
				indiceSpell=1;
			}
			if(spellChosen.getSpellType().equals("GRASS")){
				indiceSpell=2;
			}
			if(spellChosen.getSpellType().equals("ROCK")){
				indiceSpell=3;
			}
			if(spellChosen.getSpellType().equals("ELECTRIC")){
				indiceSpell=4;
			}
			if(spellChosen.getSpellType().equals("WATER")){
				indiceSpell=5;
			}
			
			//Sort type < Receveur type
			if(indiceSpell - indicePokemon == 1){
				return 0;
			}
			//Sort type > Receveur type
			if(indiceSpell - indicePokemon == -1){
				return 2;
			}
			//Sort Eau > Receveur Feu
			if(indiceSpell - indicePokemon == 4){
				return 2;
			}
			//Sort Feu < Receveur Eau
			if(indiceSpell - indicePokemon == -4){
				return 0;
			}
			//Sort type = Receveur type
				
		return 1;
	}

	
	///---Trie la liste en fonction de la vitesse des pokemons, le plus rapide attaquera en 1er---//
	private Pokemon[] getSpeed(Pokemon j1m1, Pokemon j1m2, Pokemon j2m1, Pokemon j2m2){
		int j1m1speed = j1m1.getSpeed();
		int j1m2speed = j1m2.getSpeed();
		int j2m1speed = j2m1.getSpeed();
		int j2m2speed = j2m2.getSpeed();
		
		Pokemon[] fightOrder = {j1m1,j1m2,j2m1,j2m2};
		int[] list = {j1m1speed,j1m2speed,j2m1speed,j2m2speed};
		
		Arrays.sort(list);
		list = swap(0,3,list);
		list = swap(1,2,list);
		
		Pokemon[] trieOrder = new Pokemon[4];
		int j=0;
		int i=0;
		while(j<4){
			for(i = 0; i<4; i++){
				if(j==4){
					return trieOrder;
				}
				if(list[j]==fightOrder[i].getSpeed()){
					trieOrder[j]=fightOrder[i];
					final SimplePokemon speedtemp =(SimplePokemon) fightOrder[i];
					speedtemp.setSpeed(0);
					fightOrder[i]=speedtemp;
					j++;
				}
			}
		}
	return trieOrder;
	}
	
	
	private int[] swap(int i, int j, int[] list) {
		int temp;
		temp = list[i];
		list[i]=list[j];
		list[j]=temp;
		
		return list;
	}
	
	
	private void isThatTheEnd() {
		
		int i;
		int looser1=0,looser2=0;
		
		for(i=0;i<0;i++){
			if(listOrder[i].getHP()<=0 && listOrder[i].getDresseur()==1){
				looser1+=1;
			}
			if(listOrder[i].getHP()<=0 && listOrder[i].getDresseur()==2){
				looser2+=1;
			}
		}
		if(looser1==2 || looser2==2){
			if(looser1==2){
				winner=2;
			}
			if(looser2==2){
				winner=1;	
			}
			victory = true;			
			
		}else{
			victory = false;
			
		}
	}

}