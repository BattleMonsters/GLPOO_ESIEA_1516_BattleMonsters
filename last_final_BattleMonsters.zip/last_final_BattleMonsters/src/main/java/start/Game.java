package start;


import pokemonCsv.Pokemon;
import pokemonCsv.SimplePokemon;
import start.Game;


public class Game {
	
	static DefineTirage define = DefineTirage.tirage;
	
	
	private static boolean test(String text) {
	      try {
	         Integer.parseInt(text);
	         return true;
	      } catch (NumberFormatException e) {
	         return false;
	      }
	   }
	
	public static void start() throws InterruptedException{

		boolean isItInt1;
		boolean isItInt2;

		String date1 = define.field1.getText();
		String date2 = define.field2.getText();
		
		if(date1 == null || date2 == null){
			DefineTirage.buildContentPane();
		}
	
		isItInt1 = test(date1);
		isItInt2 = test(date2);
		
		//Si ce n'est pas des entier, retour au choix des tirages
		if(!isItInt1 || !isItInt2){
			DefineTirage.buildContentPane();
		}
		
		//Modulo sur le nombre entré pour obtenir une valeur entre 1 et 220 (inclus)
		int id1 = 1 + (Integer.parseInt(date1)%220);
		int id2 = 1 + (Integer.parseInt(date2)%220);
		
		if(id1<=0){ id1=id1*(-1)+1;}
		if(id2<=0){ id2=id2*(-1)+1;}
		
		Pokemon j1m1 = BeginPokeChoice.getFirst(id1);
		Pokemon j1m2 = BeginPokeChoice.getSecond(id1);
		
		
		Pokemon j2m1 = BeginPokeChoice.getFirst(id2);
		Pokemon j2m2 = BeginPokeChoice.getSecond(id2);
		
		
		//----------------SET PLAYER----------------//
		
		j1m1 = setPlayers(j1m1,1);
		j1m2 = setPlayers(j1m2,1);
		
		j2m1 = setPlayers(j2m1,2);
		j2m2 = setPlayers(j2m2,2);
		
		Combat fight1 = new Combat().fight2v2(j1m1, j1m2,j2m1, j2m2);
		
	}
	
	


	public static Pokemon setPlayers(Pokemon poke, int player){
		
		final SimplePokemon monster = (SimplePokemon) poke;

		monster.setDresseur(player);
	
		return monster;

	}
}
