package start;

import java.io.File;
import java.util.List;

import euromillionCsv.AdvancedEuroCsv;
import euromillionCsv.CsvEuromillion;
import euromillionCsv.Tirage;
import euromillionCsv.TirageDao;
import pokemonCsv.AdvancedPokeCsv;
import pokemonCsv.CsvPokemon;
import pokemonCsv.Pokemon;
import pokemonCsv.PokemonDao;
import pokemonCsv.SimplePokemon;
import spellsCsv.AdvancedSpellsCsv;
import spellsCsv.CsvSpells;
import spellsCsv.Spell;
import spellsCsv.SpellDao;

public class BeginPokeChoice {	
	
	//----------------------------FILES----------------------------/
	
	final static String FILE_NAME = "src/main/resources/pokemon.csv";
	final static File FILE = new File(FILE_NAME);
	
	final static String FILE_NAME2 = "src/main/resources/euromillions_4.csv";
	final static File FILE2 = new File(FILE_NAME2);
	
	final static String FILE_NAME3 = "src/main/resources/spells.csv";
	final static File FILE3 = new File(FILE_NAME3);
	
	
	public static Pokemon getFirst(int id1){
		
		Tirage euro = doFindAdvancedEuro(id1);
		int p1 = euro.getStarOne();
		int n1 = euro.getnOne();
		int n2 = euro.getnTwo();
		int n3 = euro.getnThree();
		int n4 = euro.getnFour();
		int n5 = euro.getnFive();
		
		
		//---------------------------POKEMON1-------------------------//
		//System.out.println("Tirage : " +euro.getDate());
		final SimplePokemon monster1 = (SimplePokemon) doFindAdvanced(p1);
		int s1 = n1 + p1; 	if(s1 > 50){ s1 = s1-50;}
		int s2 = n2 + p1; 	if(s2 > 50){ s2 = s2-50;}
		int s3 = n3 + p1; 	if(s3 > 50){ s3 = s3-50;}
		int s4 = n4 + p1; 	if(s4 > 50){ s4 = s4-50;}
		int s5 = n5 + p1; 	if(s5 > 50){ s5 = s5-50;}
		
		
		Spell spell1= doFindSpells(s1);
		monster1.setSpell1(spell1);
		Spell spell2= doFindSpells(s2);
		monster1.setSpell2(spell2);
		Spell spell3= doFindSpells(s3);
		monster1.setSpell3(spell3);
		Spell spell4= doFindSpells(s4);
		monster1.setSpell4(spell4);
		Spell spell5= doFindSpells(s5);
		monster1.setSpell5(spell5);		
		return monster1;
		 
	}
	
	
public static Pokemon getSecond(int id2){
		
		Tirage euro = doFindAdvancedEuro(id2);
		int p2 = euro.getStarTwo();
		int n1 = euro.getnOne();
		int n2 = euro.getnTwo();
		int n3 = euro.getnThree();
		int n4 = euro.getnFour();
		int n5 = euro.getnFive();
		
		
		//---------------------------POKEMON1-------------------------//
		final SimplePokemon monster2 = (SimplePokemon) doFindAdvanced(p2);
		int s1 = n1 + p2; 	if(s1 > 50){ s1 = s1-50;}
		int s2 = n2 + p2; 	if(s2 > 50){ s2 = s2-50;}
		int s3 = n3 + p2; 	if(s3 > 50){ s3 = s3-50;}
		int s4 = n4 + p2; 	if(s4 > 50){ s4 = s4-50;}
		int s5 = n5 + p2; 	if(s5 > 50){ s5 = s5-50;}
		
		Spell spell1= doFindSpells(s1);
		monster2.setSpell1(spell1);
		Spell spell2= doFindSpells(s2);
		monster2.setSpell2(spell2);
		Spell spell3= doFindSpells(s3);
		monster2.setSpell3(spell3);
		Spell spell4= doFindSpells(s4);
		monster2.setSpell4(spell4);
		Spell spell5= doFindSpells(s5);
		monster2.setSpell5(spell5);
		
		return monster2;
		
	}
	
	
	
	
	//--------------------TIRAGES EUROMILLION-----------------//
	
	
	
	public static Tirage doFindAdvancedEuro(int id) {
		final CsvEuromillion euro = new AdvancedEuroCsv();
		euro.init(FILE2);

		return dofirstone(euro, id);
	}
	
	private static Tirage dofirstone(final TirageDao doa, final int id) {
		final List<Tirage> tirages = doa.findAllTirage();
		Tirage euro = null;
		
		euro = findDate(tirages, id);
		
		return euro;
	}
	
	private static Tirage findDate(final List<Tirage> tirages, int id) {

		Tirage euro = null;
		for (final Tirage tirage : tirages) {
			if(id == tirage.getID()){
				euro = tirage;
			}
		}
		return euro;
	}
	
	
	
	//-------------POKEMON-----------//
	
	
	public static Pokemon doFindAdvanced(int poke1) {
		final CsvPokemon poke = new AdvancedPokeCsv();
		poke.init(FILE);

		return doWork(poke, poke1);
	}

	
	private static Pokemon getPokemon1(final List<Pokemon> pokemons, int j1poke1) {
		Pokemon poke = null;
			for (final Pokemon pokemon : pokemons) {
				if(Integer.parseInt(pokemon.getStar())==j1poke1){
					poke = pokemon;
				}
			}
			return poke;
	}

	private static Pokemon doWork(final PokemonDao dao, int poke1) {
		final List<Pokemon> pokemons = dao.findAllPokemon();

		return getPokemon1(pokemons, poke1);
	}
	
	
	
	
	//---------------SPELLS-------------//
	
	public static Spell doFindSpells(int t1number) {
		final CsvSpells spell1 = new AdvancedSpellsCsv();
		spell1.init(FILE3);

		return doWSpell(spell1, t1number);
	}
	
	private static Spell getSpell1(final List<Spell> spells, int t1number) {
		Spell newspell = null;
			for (final Spell spell : spells) {
				if(spell.getNumber()==t1number){
					newspell = spell;
				}
			}
			return newspell;
	}
	
	private static Spell doWSpell(final SpellDao huhu, int t1number) {
		final List<Spell> spells = huhu.findAllSpells();
		
		return getSpell1(spells, t1number);
	}
	
	
	
}
