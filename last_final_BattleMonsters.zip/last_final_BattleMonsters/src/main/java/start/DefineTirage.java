package start;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import intgraphique.MenuIHM;
import start.DefineTirage;

public class DefineTirage extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static JFrame jframe;
	
	public static DefineTirage tirage;
	
	static JTextField field1;
	static JTextField field2;
	
	final static String BACKGROUND = "src/main/resources/bgtirage.png";
	final static String AIDE = "src/main/resources/aide.png";
	
	public static DefineTirage t;
	
	public static void buildContentPane() throws InterruptedException{
		JPanel panel = new JPanel();
		panel.setSize(1024,720);
		
		JLabel image = new JLabel( new ImageIcon(BACKGROUND));
		image.setBounds(0,0,1024,720);  
		       
		field1 = new JTextField();
		field1.setColumns(10);
		field1.setBounds(140,320,200,40);
		image.add(field1);
 
		field2 = new JTextField();
		field2.setColumns(10);
		field2.setBounds(632,320,200,40);
		image.add(field2);
		
		JButton launch = new JButton(new Launch());
		launch.setBounds(230,600,200,40);
		image.add(launch);
		
		JButton quit = new JButton(new Quit());
		quit.setBounds(550,600,200,40);
		image.add(quit);
	
		jframe = new JFrame("Choix du Tirage");
		jframe.setLayout(new BorderLayout());
		jframe.setVisible(true);
		jframe.setMinimumSize(new Dimension(1024,720));
		jframe.setLocation(190,10);
		jframe.getContentPane().add(image,BorderLayout.CENTER);
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	
	
	public static void aideScreen(){
		JLabel aide = new JLabel( new ImageIcon(AIDE));
		aide.setBounds(0,0,1024,720); 
		
		jframe = new JFrame("Aide");
		jframe.setLayout(new BorderLayout());
		jframe.setVisible(true);
		jframe.setMinimumSize(new Dimension(1024,720));
		jframe.setLocation(190,10);
		jframe.getContentPane().add(aide,BorderLayout.CENTER);
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		jframe.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				System.out.println("Number of click: " + e.getClickCount());
			     System.out.println("Click position (X, Y):  " + e.getX() + ", " + e.getY());
					if((e.getX() >= 862 && e.getX() <= 966) && (e.getY() >= 658 && e.getY() <= 690)){
						jframe.removeMouseListener(this);
						jframe.dispose();
						new MenuIHM();
					}
				}
			
		});
	}
	
	public static class Launch extends AbstractAction {

		private static final long serialVersionUID = 7183768497443802311L;

        private Launch() {
            super("Jouer");
        }

        public void actionPerformed(ActionEvent e) {
        	jframe.dispose();
            try {
				Game.start();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
	
	}
	
	public static class Quit extends AbstractAction {

		private static final long serialVersionUID = 7183768497443802311L;

        private Quit() {
            super("Quitter");
        }

        public void actionPerformed(ActionEvent e) {
            jframe.dispose();
        }
	
	}
	
}
