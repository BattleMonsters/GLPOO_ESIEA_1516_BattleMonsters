package intgraphique;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import pokemonCsv.Pokemon;
import spellsCsv.Spell;
import start.Combat;

public class FightGraph extends JPanel{
	
	private static final long serialVersionUID = 1L;
	private BufferedImage j1m1;
	private BufferedImage j1m2;
	private BufferedImage j2m1;
	private BufferedImage j2m2;
	private BufferedImage j2m1front;
	private BufferedImage j2m2front;
	
	private BufferedImage j1win;
	private BufferedImage j2win;
	
	private BufferedImage fire_icon;
	private BufferedImage elec_icon;
	private BufferedImage water_icon;
	private BufferedImage grass_icon;
	private BufferedImage rock_icon;
	private BufferedImage legend_icon;
	private BufferedImage test;
	private BufferedImage test4;
	private BufferedImage end;
	
	private BufferedImage fond;
	private BufferedImage console;
	Pokemon monster11;
	Pokemon monster12;
	Pokemon monster21;
	Pokemon monster22;
	
	String console1;
	String console2;
	String console3;
	String console4;
	String console5;
	String console6;
	
	
	BufferedImage getIconeMob(Pokemon poke){
		if(poke.getType().equals("FIRE")){
			return fire_icon;
		}
		if(poke.getType().equals("ELECTRIC")){
			return elec_icon;
		}
		if(poke.getType().equals("WATER")){
			return water_icon;
		}
		if(poke.getType().equals("GRASS")){
			return grass_icon;
		}
		if(poke.getType().equals("ROCK")){
			return rock_icon;
		}
		if(poke.getType().equals("LEGENDARY")){
			return legend_icon;
		}
		return null;
		
	}
	
	
	BufferedImage getIconeSpell(Spell spell){
		if(spell.getSpellType().equals("FIRE")){
			return fire_icon;
		}
		if(spell.getSpellType().equals("ELECTRIC")){
			return elec_icon;
		}
		if(spell.getSpellType().equals("WATER")){
			return water_icon;
		}
		if(spell.getSpellType().equals("GRASS")){
			return grass_icon;
		}
		if(spell.getSpellType().equals("ROCK")){
			return rock_icon;
		}
		return null;	
	}
	
	
	@Override
	protected void paintComponent(Graphics graph){
		
		super.paintComponent(graph);
		
		Combat jeu = Combat.jeu;
		
		boolean victory = jeu.victory;
		int current = jeu.current;
		Pokemon[] list = jeu.listOrder;
		int[] ciblelist = jeu.ciblelist;
		int displayTarget = jeu.displayTarget;
		int consoleID = jeu.consoleID;
		int cible = jeu.cible;
		int winner = jeu.winner;
		Spell spellUse = jeu.spellChosen;
		String consoleAtt = jeu.consoleAtt;
			
		
		int j1=0;
		int j2=0;
		for(int i=0;i<=3;i++){
				if(j1==1 && list[i].getDresseur()==1){
					monster12 = list[i];
				}
				if(j1==0 && list[i].getDresseur()==1){
					monster11 = list[i];
					j1++;
				}
				if(j2==1 && list[i].getDresseur()==2){
					monster22 = list[i];
				}
				if(j2==0 && list[i].getDresseur()==2){
					monster21 = list[i];
					j2++;
				}		
		}

		Pokemon attaquant = list[current];
		
		try {
			/* INITIALISATION DES IMAGES/ICONES */
			j1m1 = ImageIO.read(new File(monster11.getFrontPict()));
			j1m2 = ImageIO.read(new File(monster12.getFrontPict()));
			j2m1 = ImageIO.read(new File(monster21.getBackPict()));
			j2m2 = ImageIO.read(new File(monster22.getBackPict()));
			j2m1front = ImageIO.read(new File(monster21.getFrontPict()));
			j2m2front = ImageIO.read(new File(monster22.getFrontPict()));
			fire_icon = ImageIO.read(new File("src/main/resources/elem-icon/fire-icone.png"));
			elec_icon = ImageIO.read(new File("src/main/resources/elem-icon/elec-icone.png"));
			water_icon = ImageIO.read(new File("src/main/resources/elem-icon/water-icone.png"));
			grass_icon = ImageIO.read(new File("src/main/resources/elem-icon/grass-icone.png"));
			rock_icon = ImageIO.read(new File("src/main/resources/elem-icon/rock-icone.png"));
			legend_icon = ImageIO.read(new File("src/main/resources/elem-icon/legend-icone.png"));
			test = ImageIO.read(new File("src/main/resources/test.png"));
			test4 = ImageIO.read(new File("src/main/resources/test4.png"));
			fond = ImageIO.read(new File("src/main/resources/fondcombat.png"));
			console = ImageIO.read(new File("src/main/resources/opaque.png"));
			end = ImageIO.read(new File("src/main/resources/bgend2.png"));
			j1win = ImageIO.read(new File("src/main/resources/j1win.png"));
			j2win = ImageIO.read(new File("src/main/resources/j2win.png"));
			
			
		} catch (IOException ex) {
	      //  Logger.getLogger(ClassName.class.getName()).log(Level.SEVERE, null, ex);//Change ClassName to your class Name
	    }
		
		
		graph.drawImage(fond, 0, 0, 1024, 720, this);
		
		
		/* AFFICHAGE DE LA BARRE DE VIE ROUGE DU POKEMON */
		graph.setColor(new Color(255,0,0));
		graph.fillRect(50, 310, 200, 10); 	//Bas gauche
		graph.fillRect(330, 310, 200, 10); 	//Bas droite
		graph.fillRect(500, 40, 200, 10);	//Haut gauche
		graph.fillRect(750, 40, 200, 10);	//Haut droite
		
		/* AFFICHAGE DE LA BARRE DE VIE VERTE DU POKEMON */
		graph.setColor(new Color(0,255,0));
		graph.fillRect(50, 310, monster22.getHP()/3, 10);		//Bas gauche
		graph.fillRect(330, 310, monster21.getHP()/3, 10);	//Bas droite
		graph.fillRect(500, 40, monster12.getHP()/3, 10);		//Haut gauche
		graph.fillRect(750, 40, monster11.getHP()/3, 10); 	//Haut droite
		
		if(monster11.getHP()>0){
			graph.drawImage(j1m1, 720, 60, 240, 210, this);		//Haut droite
		}
		if(monster12.getHP()>0){
			graph.drawImage(j1m2, 470, 60, 240, 210, this);		//Haut gauche
		}
		if(monster21.getHP()>0){
			graph.drawImage(j2m1, 300, 330, 250, 220, this);	//Bas droite
		}
		if(monster22.getHP()>0){
			graph.drawImage(j2m2, 10, 330, 250, 220, this);		//Bas gauche
		}
		
		graph.setColor(Color.BLACK);
		graph.fillRect(35, 27, 90, 35);
		graph.setColor(Color.WHITE);
		Font fontt = new Font(" Arial ",Font.BOLD,16);
		String tour = "Tour :" + jeu.tour;
		graph.setFont(fontt);
		graph.drawString(tour, (int) 50,50);
		
		/* AFFICHAGE DU NOM DU POKEMON */
		String namep1m1 = "" + monster11.getName();
		String namep1m2 = "" + monster12.getName();
		String namep2m1 = "" + monster21.getName();
		String namep2m2 = "" + monster22.getName();
		graph.setColor(Color.BLACK);
		Font fonte = new Font(" Arial ",Font.BOLD,16);
		graph.setFont(fonte);
		graph.drawString(namep1m1, (int) 775,35);
		graph.drawString(namep1m2, (int) 525,35);
		graph.drawString(namep2m1, (int) 355,305);
		graph.drawString(namep2m2, (int) 75,305);
		
		
		/* AFFICHAGE DU TYPE A COTE DU NOM */
		
		BufferedImage icon11 = getIconeMob(monster11);
		BufferedImage icon12 = getIconeMob(monster12);
		BufferedImage icon21 = getIconeMob(monster21);
		BufferedImage icon22 = getIconeMob(monster22);
		
		graph.drawImage(icon11, 748, 15, 25, 25, this);	
		graph.drawImage(icon12, 498, 15, 25, 25, this);	
		graph.drawImage(icon21, 328, 285, 25, 25, this);	
		graph.drawImage(icon22, 48, 285, 25, 25, this);	
		
		
		/* AFFICHAGE DU STATUS DU POKEMON */
		
		Font fontStatus = new Font(" Arial ",Font.BOLD,11);
		graph.setFont(fontStatus);
		
		if(monster11.getStatus().equals("PARA")){
			graph.setColor(new Color(255,255,0));
			graph.fillRect(910, 23, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("PAR", (int) 917,35);
		}
		if(monster12.getStatus().equals("PARA")){
			graph.setColor(new Color(255,255,0));
			graph.fillRect(660, 23, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("PAR", (int) 667,35);
		}
		if(monster21.getStatus().equals("PARA")){
			graph.setColor(new Color(255,255,0));
			graph.fillRect(490, 292, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("PAR", (int) 497,304);}
		
		if(monster22.getStatus().equals("PARA")){
			graph.setColor(new Color(255,255,0));
			graph.fillRect(210, 292, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("PAR", (int) 217,304);
		}
		
		if(monster11.getStatus().equals("BURN")){
			graph.setColor(new Color(255,85,0));
			graph.fillRect(910, 23, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("BURN", (int) 917,35);
		}
		if(monster12.getStatus().equals("BURN")){
			graph.setColor(new Color(255,85,0));
			graph.fillRect(660, 23, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("BURN", (int) 667,35);
		}
		if(monster21.getStatus().equals("BURN")){
			graph.setColor(new Color(255,85,0));
			graph.fillRect(490, 292, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("BURN", (int) 497,304);
		}
		
		if(monster22.getStatus().equals("BURN")){
			graph.setColor(new Color(255,85,0));
			graph.fillRect(210, 292, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("BURN", (int) 217,304);
		}	
		
		if(monster11.getStatus().equals("FROZEN")){
			graph.setColor(new Color(51,255,255));
			graph.fillRect(910, 23, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("GEL", (int) 917,35);
		}
		if(monster12.getStatus().equals("FROZEN")){
			graph.setColor(new Color(51,255,255));
			graph.fillRect(660, 23, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("GEL", (int) 667,35);
		}
		if(monster21.getStatus().equals("FROZEN")){
			graph.setColor(new Color(51,255,255));
			graph.fillRect(490, 292, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("GEL", (int) 497,304);
		}
		
		if(monster22.getStatus().equals("FROZEN")){
			graph.setColor(new Color(51,255,255));
			graph.fillRect(210, 292, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("GEL", (int) 217,304);
		}	
		if(monster11.getStatus().equals("CONFUSED")){
			graph.setColor(new Color(204,153,255));
			graph.fillRect(910, 23, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("CONF", (int) 917,35);
		}
		if(monster12.getStatus().equals("CONFUSED")){
			graph.setColor(new Color(204,153,255));
			graph.fillRect(660, 23, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("CONF", (int) 667,35);
		}
		if(monster21.getStatus().equals("CONFUSED")){
			graph.setColor(new Color(204,153,255));
			graph.fillRect(490, 292, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("CONF", (int) 497,304);
		}
		
		if(monster22.getStatus().equals("CONFUSED")){
			graph.setColor(new Color(204,153,255));
			graph.fillRect(210, 292, 40, 15);
			graph.setColor(new Color(0,0,0));
			graph.drawString("CONF", (int) 217,304);
		}	
			
	if(victory==false){
		
		/*  AFFICHER LES CIBLES */
		
		if(displayTarget==1){ 
			//white
			
			
			graph.setColor(new Color(255,255,255));
			graph.fillRect(42,570,920,100);
			graph.drawImage(test, 42,570,920,100, this);
			
			BufferedImage icone11 = getIconeMob(monster11);	
			BufferedImage icone12 = getIconeMob(monster12);	
			BufferedImage icone21 = getIconeMob(monster21);	
			BufferedImage icone22 = getIconeMob(monster22);	
				
			if(ciblelist[0]!=8){			
				if(list[ciblelist[0]]==monster11){
					graph.drawImage(j1m1, 90, 590, 50, 50, this);		//Haut droite
					graph.drawImage(icone11, 300, 590, 50, 50, this);
				}
				if(list[ciblelist[0]]==monster12){
					graph.drawImage(j1m2, 90, 590, 50, 50, this);		//Haut gauche
					graph.drawImage(icone12, 300, 590, 50, 50, this);
				}
				if(list[ciblelist[0]]==monster21){
					graph.drawImage(j2m1front, 90, 590, 50, 50, this);		//Bas droite
					graph.drawImage(icone21, 300, 590, 50, 50, this);
				}
				if(list[ciblelist[0]]==monster22){
					graph.drawImage(j2m2front, 90, 590, 50, 50, this);		//Bas gauche
					graph.drawImage(icone22, 300, 590, 50, 50, this);
				}
				graph.setColor(Color.BLACK);
				Font fonttarget = new Font(" Arial ",Font.PLAIN,16);
				graph.setFont(fonttarget);
				graph.drawString(list[ciblelist[0]].getName(), (int) 160,625);
				
			}
			if(ciblelist[1]!=8){			
				if(list[ciblelist[1]]==monster11){
					graph.drawImage(j1m1, 550, 590, 50, 50, this);		//Haut droite
					graph.drawImage(icone11, 780, 590, 50, 50, this);
				}
				if(list[ciblelist[1]]==monster12){
					graph.drawImage(j1m2, 550, 590, 50, 50, this);		//Haut gauche
					graph.drawImage(icone12, 780, 590, 50, 50, this);
				}
				if(list[ciblelist[1]]==monster21){
					graph.drawImage(j2m1front, 550, 590, 50, 50, this);		//Bas droite
					graph.drawImage(icone21, 780, 590, 50, 50, this);
				}
				if(list[ciblelist[1]]==monster22){
					graph.drawImage(j2m2front, 550, 590, 50, 50, this);		//Bas gauche
					graph.drawImage(icone22, 780, 590, 50, 50, this);
				}
			
				graph.setColor(Color.BLACK);
				Font fonttarget = new Font(" Arial ",Font.PLAIN,16);
				graph.setFont(fonttarget);
				graph.drawString(list[ciblelist[1]].getName(), (int) 640,625);
			
				
			}
			
			
		}
		
		/*  AFFICHER LES ATTAQUES  */
		
		if(displayTarget==2){	
			
			BufferedImage iconespell1 = getIconeSpell(attaquant.getSpell1());	
			BufferedImage iconespell2 = getIconeSpell(attaquant.getSpell2());	
			BufferedImage iconespell3 = getIconeSpell(attaquant.getSpell3());	
			BufferedImage iconespell4 = getIconeSpell(attaquant.getSpell4());	
			BufferedImage iconespell5 = getIconeSpell(attaquant.getSpell5());
			
			graph.drawImage(test4, 42,570,920,100, this);
			
			String spell1 = "" + attaquant.getSpell1().getSpellName();
			String spell2 = "" + attaquant.getSpell2().getSpellName();
			String spell3 = "" + attaquant.getSpell3().getSpellName();
			String spell4 = "" + attaquant.getSpell4().getSpellName();
			String spell5 = "" + attaquant.getSpell5().getSpellName();
			graph.setColor(Color.BLACK);
			Font font = new Font(" Arial ",Font.PLAIN,12);
			graph.setFont(font);
			graph.drawString(spell1, (int) 113,625);
			graph.drawString(spell2, (int) 296,625);
			graph.drawString(spell3, (int) 480,625);
			graph.drawString(spell4, (int) 664,625);
			graph.drawString(spell5, (int) 848,625);
			
			
			graph.drawImage(iconespell1, 58, 600, 40, 40, this);
			graph.drawImage(iconespell2, 241, 600, 40, 40, this);
			graph.drawImage(iconespell3, 425, 600, 40, 40, this);
			graph.drawImage(iconespell4, 609, 600, 40, 40, this);
			graph.drawImage(iconespell5, 793, 600, 40, 40, this);
			
		}
		
	}
	
	
	/* -- AFFICHAGE CONSOLE -- */

	graph.drawImage(console, 707, 450, 272, 20, this);
	graph.setColor(Color.BLACK);
	Font consolefont1 = new Font(" Arial ",Font.PLAIN,12);
	graph.setFont(consolefont1);	
	if(consoleAtt!=null){
		graph.drawString(consoleAtt, (int) 750,464);
		if(attaquant==monster11){
			graph.drawImage(j1m1, 720,450, 20, 20, this);
		}
		if(attaquant==monster12){
			graph.drawImage(j1m2, 720,450, 20, 20, this);
		}
		if(attaquant==monster21){
			graph.drawImage(j2m1front, 720,450, 20, 20, this);
		}
		if(attaquant==monster22){
			graph.drawImage(j2m2front, 720,450, 20, 20, this);
		}
	}

	
	
	
	/* VICTOIRE */
	
	if(victory==true){
		System.out.println(winner);
		graph.drawImage(end, 0,0, 1024, 720, this);
		//graph.drawImage(j1win, 220,20, 600, 300, this);
		//graph.drawImage(j1win, 110,90, 1000, 430, this);
		if(monster11.getHP()<=0 && monster12.getHP()<=0){
			graph.drawImage(j2win, 220,20, 600, 300, this);
			graph.drawImage(j2m1front, 250,220,245, 220, this);
			graph.drawImage(j2m2front, 520,220, 245, 220, this);
		}
		if(monster21.getHP()<=0 && monster22.getHP()<=0){
			graph.drawImage(j1win, 220,20, 600, 300, this);
			graph.drawImage(j1m1, 250,220,245, 220, this);
			graph.drawImage(j1m2, 520,220, 245, 220, this);
		}
	}
	
	}
}
