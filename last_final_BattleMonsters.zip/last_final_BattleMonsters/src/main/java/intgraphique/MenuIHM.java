package intgraphique;

import static java.awt.BorderLayout.SOUTH;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;

import start.DefineTirage;

public class MenuIHM extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public JFrame jframe;
	final static String MENU_FILE = "src/main/resources/bgmenu.png";
	
	
	public MenuIHM(){
		jframe = new JFrame("Jeu");
		jframe.setVisible(true);
		jframe.setMinimumSize(new Dimension(1024,720));
		jframe.setContentPane(new DisplayPict(MENU_FILE)); 
		jframe.getContentPane().setLayout(new BorderLayout()); 
		
		jframe.setLocation(190,10);
		
		jframe.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				System.out.println("Number of click: " + e.getClickCount());
			    System.out.println("Click position (X, Y):  " + e.getX() + ", " + e.getY());
					if((e.getX() >= 470 && e.getX() <= 580 ) && (e.getY() >= 440 && e.getY() <= 490) ){
						
						jframe.removeMouseListener(this);
						jframe.dispose();
						try {
							DefineTirage.buildContentPane();
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					if((e.getX() >= 460 && e.getX() <= 600 ) && (e.getY() >= 580 && e.getY() <= 630 )){
						jframe.removeMouseListener(this);
						jframe.dispose();
					
						
					
					}
					if((e.getX() >= 460 && e.getX() <= 600 ) && (e.getY() >= 513 && e.getY() <= 565 )){
						
						jframe.removeMouseListener(this);
						jframe.dispose();
						DefineTirage.aideScreen();
					}	
					System.out.println("Number of click: " + e.getClickCount());
				     System.out.println("Click position (X, Y):  " + e.getX() + ", " + e.getY());
			}
		});
	}
}