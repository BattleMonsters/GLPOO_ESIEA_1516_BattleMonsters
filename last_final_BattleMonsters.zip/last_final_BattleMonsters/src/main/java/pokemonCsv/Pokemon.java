package pokemonCsv;

import java.io.Serializable;

import spellsCsv.Spell;

public interface Pokemon extends Serializable {

	String getStar();
	String getName();
	String getType();

	int getDresseur();

	Spell getSpell1();
	Spell getSpell2();
	Spell getSpell3();
	Spell getSpell4();
	Spell getSpell5();
	String getStatus();
	int getReloading();
	int getTourAffected();
	
	int getHP();
	int getSpeed();
	
	String getFrontPict();
	String getBackPict();
}
