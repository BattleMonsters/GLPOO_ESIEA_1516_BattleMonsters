package pokemonCsv;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import pokemonCsv.AbstractCsvPokemon;
import pokemonCsv.AdvancedPokeCsv;
import pokemonCsv.Pokemon;
import pokemonCsv.SimplePokemon;



public class AdvancedPokeCsv extends AbstractCsvPokemon {

	private final static String SEPARATOR = ";";


	private List<String> getLignesFromFile() {

		//System.out.println("getLignesFromFile");

		final List<String> lignes = new ArrayList<String>();

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);

			for (String ligne = br.readLine(); ligne != null; ligne = br.readLine()) {

				// Suppression des espaces en trop
				ligne = ligne.trim();

				// Filtre des lignes vides
				if (ligne.isEmpty()) {
					continue;
				}

				// Filtre des lignes de commentaire
				if (ligne.startsWith("#")) {
					continue;
				}

				lignes.add(ligne);
			}
		} catch (IOException e) {
			System.out.println("Lecture impossible");
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					System.out.println("Fermeture impossible");
				}
			}
			if (fr != null) {
				try {
					fr.close();
				} catch (IOException e) {
					System.out.println("Fermeture impossible");
				}
			}
		}

		return lignes;

	}

	protected Pokemon transformLigneToPokemon(final String[] values) throws Exception {
		//System.out.println("transformLigneToPokemon");

		final SimplePokemon pokemon = new SimplePokemon();
		pokemon.setStar(values[0]);
		pokemon.setName(values[1]);
		pokemon.setType(values[2]);
		pokemon.setHP(Integer.parseInt(values[3]));
		pokemon.setSpeed(Integer.parseInt(values[5]));
		pokemon.setStatus("null");
		pokemon.setTourAffected(0);
		pokemon.setReloading(0);
		pokemon.setFrontPict(values[6]);
		pokemon.setBackPict(values[7]);
		
		return pokemon;
	

	
	}

	private Pokemon transformLigneToPokemon(final String ligne) throws Exception {
		//System.out.println("transformLigneToPokemon");

		final String[] values = ligne.split(SEPARATOR);

		return transformLigneToPokemon(values);
	}

	protected void transformEntetes(final String[] tabEntetes) {
		//System.out.println("transformEntetes");

		entetes = new ArrayList<String>(tabEntetes.length);

		for (String entete : tabEntetes) {
			entetes.add(entete);
		}
	}

	private void transformEntetes(final String ligneEntete) {
		//System.out.println("transformEntetes");

		final String[] tabEntetes = ligneEntete.split(SEPARATOR);

		transformEntetes(tabEntetes);
	}

	/**
	 * Chargement des chiens.
	 */
	@Override
	protected void reloadPokemon() {
		//System.out.println("reloadPokemon");

		if (file == null) {
			throw new IllegalStateException("Le fichier est nul...");
		}

		try {
			final List<String> lignes = getLignesFromFile();

			final String ligneEntete = lignes.remove(0);
			//System.out.println("Entetes : " + ligneEntete);
			transformEntetes(ligneEntete);

			pokemons = new ArrayList<Pokemon>(lignes.size());
			pokemonMapByNom = new HashMap<String, Pokemon>(lignes.size());
			for (String ligne : lignes) {
				final Pokemon pokemon = transformLigneToPokemon(ligne);
				pokemons.add(pokemon);

				pokemonMapByNom.put(pokemon.getName(), pokemon);
			}

		} catch (Exception e) {
			System.out.println("Une erreur s'est produite...");
		}

	}

}
