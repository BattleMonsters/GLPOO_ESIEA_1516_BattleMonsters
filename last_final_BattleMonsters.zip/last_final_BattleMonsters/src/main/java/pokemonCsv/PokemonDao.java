package pokemonCsv;

import java.util.List;

import pokemonCsv.Pokemon;

public interface PokemonDao {

	List<Pokemon> findAllPokemon();

	Pokemon findPokemonByNom(final String nom);

}