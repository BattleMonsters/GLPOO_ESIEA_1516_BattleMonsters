package pokemonCsv;

import spellsCsv.Spell;

public class SimplePokemon implements Pokemon {
	
	private static final long serialVersionUID = 1L;
	public String star;
	public String name;
	public String type;
	public int dresseur;
	public Spell spell1;
	public Spell spell2;
	public Spell spell3;
	public Spell spell4;
	public Spell spell5;
	public String status;
	public int reload;
	public int nbTourAffect;
	public int hp;
	public int speed;
	public String frontpict;
	public String backpict;
	
	
	
	public SimplePokemon() {
		// rien...
	}

	public SimplePokemon(final String name) {
		this.name = name;
	}

	public SimplePokemon(final String name, final String type) {
		this(name);
		this.type = type;
	}


	// ################################################
	// ############## Methodes diverses ###############
	// ################################################

	@Override
	public String toString() {
		return "\n\n" + star + ": Pokemon  " + "\n Name : " + name + " \n Dresseur :" + dresseur  + " \n Type :" + type + "\n\n Spells" + ": \n" + spell1 + "\n" + spell2 + "\n" + spell3+ "\n"  + spell4;
	}

	// ################################################
	// ############# Getters et setters ###############
	// ################################################
	
	public String getStar() {
		return star;
	}

	public void setStar(String star) {
		this.star = star;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getDresseur() {
		return dresseur;
	}

	public void setDresseur(int dresseur) {
		this.dresseur = dresseur;
	}
	
	public Spell getSpell1() {
		return spell1;
	}

	public void setSpell1(Spell spell1) {
		this.spell1 = spell1;
	}
	
	public Spell getSpell2() {
		return spell2;
	}

	public void setSpell2(Spell spell2) {
		this.spell2 = spell2;
	}
	
	public Spell getSpell3() {
		return spell3;
	}

	public void setSpell3(Spell spell3) {
		this.spell3 = spell3;
	}
	
	public Spell getSpell4() {
		return spell4;
	}

	public void setSpell4(Spell spell4) {
		this.spell4 = spell4;
	}
	
	public Spell getSpell5() {
		return spell5;
	}

	public void setSpell5(Spell spell5) {
		this.spell5 = spell5;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public int getReloading(){
		return reload;
	}
	public void setReloading(int reload){
		this.reload = reload;
	}
	
	public int getHP() {
		return hp;
	}

	public void setHP(int hp) {
		this.hp = hp;
	}
	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int getTourAffected() {
		return nbTourAffect;
	}

	public void setTourAffected(int nbTourAffect) {
		this.nbTourAffect = nbTourAffect;
	}
	
	public String getFrontPict() {
		return frontpict;
	}

	public void setFrontPict(String frontpict) {
		this.frontpict = frontpict;
	}
	public String getBackPict() {
		return backpict;
	}

	public void setBackPict(String backpict) {
		this.backpict = backpict;
	}

	
}
