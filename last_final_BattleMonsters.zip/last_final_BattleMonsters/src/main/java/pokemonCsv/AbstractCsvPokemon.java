package pokemonCsv;

import pokemonCsv.AbstractCsvPokemon;
import pokemonCsv.CsvPokemon;
import pokemonCsv.Pokemon;


import java.io.File;
import java.util.List;
import java.util.Map;

public abstract class AbstractCsvPokemon implements CsvPokemon {


	protected File file;
	protected List<Pokemon> pokemons;
	protected Map<String, Pokemon> pokemonMapByNom;
	protected List<String> entetes;


	protected abstract void reloadPokemon();;

	public void init(File file) {
		//System.out.println("init");
		this.file = file;

		reloadPokemon();
	}

	public List<Pokemon> findAllPokemon() {
	//	System.out.println("findAllPokemon");

		if (pokemons == null) {
			throw new IllegalStateException("La liste n'a pas encore ete initialisee...");
		}

		return pokemons;
	}

	public Pokemon findPokemonByNom(final String nom) {

		if (nom == null || nom.isEmpty()) {
			throw new IllegalArgumentException("Le nom ne peut pas etre vide.");
		}

		if (pokemons == null) {
			throw new IllegalStateException("La liste n'a pas encore ete initialisee...");
		}

		return pokemonMapByNom.get(nom);
	}


	public File getFile() {
		return file;
	}

	public List<String> getEntetes() {
		return entetes;
	}
}

