package euromillionCsv;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AdvancedEuroCsv extends AbstractCsvEuromillion {

	private final static String SEPARATOR = ";";


	private List<String> getLignesFromFile() {

		//System.out.println("getLignesFromFile");

		final List<String> lignes = new ArrayList<String>();

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);

			for (String ligne = br.readLine(); ligne != null; ligne = br.readLine()) {

				// Suppression des espaces en trop
				ligne = ligne.trim();

				// Filtre des lignes vides
				if (ligne.isEmpty()) {
					continue;
				}

				// Filtre des lignes de commentaire
				if (ligne.startsWith("#")) {
					continue;
				}

				lignes.add(ligne);
			}
		} catch (IOException e) {
			System.out.println("Lecture impossible");
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					System.out.println("Fermeture impossible");
				}
			}
			if (fr != null) {
				try {
					fr.close();
				} catch (IOException e) {
					System.out.println("Fermeture impossible");
				}
			}
		}
		
		return lignes;

	}

	protected Tirage transformLigneToTirage(final String[] values) throws Exception {

		final SimpleTirage tirage = new SimpleTirage();
		tirage.setDate(values[0]);
		tirage.setnOne(Integer.parseInt(values[1]));
		tirage.setnTwo(Integer.parseInt(values[2]));
		tirage.setnThree(Integer.parseInt(values[3]));
		tirage.setnFour(Integer.parseInt(values[4]));
		tirage.setnFive(Integer.parseInt(values[5]));
		tirage.setStarOne(Integer.parseInt(values[6]));
		tirage.setStarTwo(Integer.parseInt(values[7]));
		tirage.setID(Integer.parseInt(values[8]));
		
		return tirage;

	}

	
	private Tirage transformLigneToTirage(final String ligne) throws Exception {

		final String[] values = ligne.split(SEPARATOR);

		return transformLigneToTirage(values);
	}

	protected void transformEntetes(final String[] tabEntetes) {
		//System.out.println("transformEntetes");

		entetes = new ArrayList<String>(tabEntetes.length);

		for (String entete : tabEntetes) {
			entetes.add(entete);
		}
	}

	private void transformEntetes(final String ligneEntete) {
		//System.out.println("transformEntetes");

		final String[] tabEntetes = ligneEntete.split(SEPARATOR);

		transformEntetes(tabEntetes);
	}


	@Override
	protected void reloadTirage() {
		//System.out.println("reloadTirage");

		if (file == null) {
			throw new IllegalStateException("Le fichier est nul...");
		}

		try {
			final List<String> lignes = getLignesFromFile();

			final String ligneEntete = lignes.remove(0);
			//System.out.println("Entetes : " + ligneEntete);
			transformEntetes(ligneEntete);

			tirages = new ArrayList<Tirage>(lignes.size());
			tirageMapByDate = new HashMap<String, Tirage>(lignes.size());
			for (String ligne : lignes) {
				final Tirage tirage = transformLigneToTirage(ligne);
				tirages.add(tirage);

				tirageMapByDate.put(tirage.getDate(), tirage);
			}

		} catch (Exception e) {
			System.out.println("Une erreur s'est produite...");
		}

	}

}
