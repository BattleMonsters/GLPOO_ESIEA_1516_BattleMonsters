package euromillionCsv;

public class SimpleTirage implements Tirage{
	
	private static final long serialVersionUID = 1L;
	private String date;
	private int nOne;
	private int nTwo;
	private int nThree;
	private int nFour;
	private int nFive;
	private int starOne;
	private int starTwo;
	private int idTirage;
	
	
	
	public SimpleTirage() {
		// rien...
	}

	public SimpleTirage(final String date) {
		this.date = date;
	}

	public SimpleTirage(final String date, final int nOne) {
		this(date);
		this.nOne = nOne;
	}

	// ################################################
	// ############## Methodes diverses ###############
	// ################################################

	@Override
	public String toString() {
		return date + ": Euromillion  " + "\n Number : " + nOne + " \n Pokemon number :" + starOne;
	}

	// ################################################
	// ############# Getters et setters ###############
	// ################################################
	
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getnOne() {
		return nOne;
	}

	public void setnOne(int i) {
		this.nOne = i;
	}

	public int getnTwo() {
		return nTwo;
	}

	public void setnTwo(int nTwo) {
		this.nTwo = nTwo;
	}
	
	public int getnThree() {
		return nThree;
	}

	public void setnThree(int nThree) {
		this.nThree = nThree;
	}
	
	public int getnFour() {
		return nFour;
	}

	public void setnFour(int nFour) {
		this.nFour = nFour;
	}
	
	public int getnFive() {
		return nFive;
	}

	public void setnFive(int nFive) {
		this.nFive = nFive;
	}
	
	public int getStarOne() {
		return starOne;
	}

	public void setStarOne(int starOne) {
		this.starOne = starOne;
	}
	
	public int getStarTwo() {
		return starTwo;
	}

	public void setStarTwo(int starTwo) {
		this.starTwo = starTwo;
	}

	public int getID() {
		return idTirage;
	}

	public void setID(int idTirage) {
		this.idTirage = idTirage;
	}
	

}
