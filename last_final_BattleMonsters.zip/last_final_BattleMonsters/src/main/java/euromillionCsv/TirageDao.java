package euromillionCsv;

import java.util.List;

public interface TirageDao {

	List<Tirage> findAllTirage();

	Tirage findTirageByDate(final String nom);

}