package euromillionCsv;

import java.io.File;
import java.util.List;
import java.util.Map;

public abstract class AbstractCsvEuromillion implements CsvEuromillion {

		protected File file;
		protected List<Tirage> tirages;
		protected Map<String, Tirage> tirageMapByDate;
		protected List<String> entetes;


		protected abstract void reloadTirage();;

		public void init(File file) {
			//System.out.println("init");
			this.file = file;

			reloadTirage();
		}

		public List<Tirage> findAllTirage() {
			//System.out.println("findAllTirage");

			if (tirages == null) {
				throw new IllegalStateException("La liste n'a pas encore ete initialisee...");
			}

			return tirages;
		}

		public Tirage findTirageByDate(final String date) {

			if (date == null || date.isEmpty()) {
				throw new IllegalArgumentException("Le nom ne peut pas etre vide.");
			}

			if (tirages == null) {
				throw new IllegalStateException("La liste n'a pas encore ete initialisee...");
			}

			return tirageMapByDate.get(date);
		}


		public File getFile() {
			return file;
		}

		public List<String> getEntetes() {
			return entetes;
		}
}



