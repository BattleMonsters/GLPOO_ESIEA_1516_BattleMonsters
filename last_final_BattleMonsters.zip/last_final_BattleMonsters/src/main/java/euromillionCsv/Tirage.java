package euromillionCsv;
import java.io.Serializable;


public interface Tirage extends Serializable {

	String getDate();
	int getnOne();
	int getnTwo();
	int getnThree();
	int getnFour();
	int getnFive();
	int getStarOne();
	int getStarTwo();
	int getID();

}

