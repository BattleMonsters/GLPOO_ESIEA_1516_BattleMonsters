package spellsCsv;

import java.io.Serializable;

public interface Spell extends Serializable {

	int getNumber();
	String getSpellName();
	String getSpellType();
	int getDammages();
	String getEffect();
	int getPourcent();

}


