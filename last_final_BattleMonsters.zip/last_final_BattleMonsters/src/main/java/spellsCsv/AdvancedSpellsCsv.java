package spellsCsv;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class AdvancedSpellsCsv extends AbstractCsvSpells {

	
	private final static String SEPARATOR = ";";


	private List<String> getLignesFromFile() {

		//System.out.println("getLignesFromFile");

		final List<String> lignes = new ArrayList<String>();

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);

			for (String ligne = br.readLine(); ligne != null; ligne = br.readLine()) {

				// Suppression des espaces en trop
				ligne = ligne.trim();

				// Filtre des lignes vides
				if (ligne.isEmpty()) {
					continue;
				}

				// Filtre des lignes de commentaire
				if (ligne.startsWith("#")) {
					continue;
				}

				lignes.add(ligne);
			}
		} catch (IOException e) {
			System.out.println("Lecture impossible");
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					System.out.println("Fermeture impossible");
				}
			}
			if (fr != null) {
				try {
					fr.close();
				} catch (IOException e) {
					System.out.println("Fermeture impossible");
				}
			}
		}

		return lignes;

	}

	protected Spell transformLigneToSpell(final String[] values) throws Exception {

		final SimpleSpell spell = new SimpleSpell();
		spell.setNumber(Integer.parseInt(values[0]));
		spell.setSpellName(values[1]);
		spell.setSpellType(values[3]);
		spell.setDammages(Integer.parseInt(values[4]));
		spell.setEffect(values[5]);
		spell.setPourcent(Integer.parseInt(values[6]));
		return spell;

	}

	private Spell transformLigneToSpell(final String ligne) throws Exception {


		final String[] values = ligne.split(SEPARATOR);

		return transformLigneToSpell(values);
	}

	protected void transformEntetes(final String[] tabEntetes) {

		entetes = new ArrayList<String>(tabEntetes.length);

		for (String entete : tabEntetes) {
			entetes.add(entete);
		}
	}

	private void transformEntetes(final String ligneEntete) {
		final String[] tabEntetes = ligneEntete.split(SEPARATOR);
		transformEntetes(tabEntetes);
	}

	/**
	 * Chargement des chiens.
	 */
	@Override
	protected void reloadSpell() {
		if (file == null) {
			throw new IllegalStateException("Le fichier est nul...");
		}

		try {
			final List<String> lignes = getLignesFromFile();

			final String ligneEntete = lignes.remove(0);
			//System.out.println("Entetes : " + ligneEntete);
			transformEntetes(ligneEntete);

			spells = new ArrayList<Spell>(lignes.size());
			spellMapByNom = new HashMap<String, Spell>(lignes.size());
			for (String ligne : lignes) {
				final Spell spell = transformLigneToSpell(ligne);
				spells.add(spell);

				spellMapByNom.put(spell.getSpellName(), spell);
			}

		} catch (Exception e) {
			System.out.println("Une erreur s'est produite...");
		}

	}
	
	
}
