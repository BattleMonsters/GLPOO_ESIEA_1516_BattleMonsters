package spellsCsv;

import spellsCsv.Spell;

public class SimpleSpell implements Spell{

	private static final long serialVersionUID = 1L;
	private int number;
	private String spellname;
	private String spelltype;
	private int dammages;
	private String effect;
	private int pourcent;
	
	
	
	public SimpleSpell() {
		// rien...
	}

	public SimpleSpell(final String spellname) {
		this.spellname = spellname;
	}

	public SimpleSpell(final String spellname, final String spelltype) {
		this(spellname);
		this.spelltype = spelltype;
	}


	// ################################################
	// ############## Methodes diverses ###############
	// ################################################

	@Override
	public String toString() {
		return " Name : " + spellname + "	Type :" + spelltype;
	}

	// ################################################
	// ############# Getters et setters ###############
	// ################################################
	
	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getSpellName() {
		return spellname;
	}

	public void setSpellName(String spellname) {
		this.spellname = spellname;
	}

	public String getSpellType() {
		return spelltype;
	}

	public void setSpellType(String spelltype) {
		this.spelltype = spelltype;
	}
	
	public int getDammages() {
		return dammages;
	}

	public void setDammages(int dammages) {
		this.dammages = dammages;
	}
	
	public String getEffect() {
		return effect;
	}

	public void setEffect(String effect) {
		this.effect = effect;
	}
	public int getPourcent() {
		return pourcent;
	}

	public void setPourcent(int pourcent) {
		this.pourcent = pourcent;
	}

	
	
}
