package spellsCsv;

import java.io.File;
import java.util.List;
import java.util.Map;

public abstract class AbstractCsvSpells implements CsvSpells {
  
	protected File file;
	protected List<Spell> spells;
	protected Map<String, Spell> spellMapByNom;
	protected List<String> entetes;


	protected abstract void reloadSpell();;

	public void init(File file) {
		//System.out.println("init");
		this.file = file;

		reloadSpell();
	}

	public List<Spell> findAllSpells() {
		if (spells == null) {
			throw new IllegalStateException("La liste n'a pas encore ete initialisee...");
		}

		return spells;
	}

	public Spell findSpellByNom(final String nom) {

		if (nom == null || nom.isEmpty()) {
			throw new IllegalArgumentException("Le nom ne peut pas etre vide.");
		}

		if (spells == null) {
			throw new IllegalStateException("La liste n'a pas encore ete initialisee...");
		}

		return spellMapByNom.get(nom);
	}


	public File getFile() {
		return file;
	}

	public List<String> getEntetes() {
		return entetes;
	}
	
}
