package spellsCsv;

import java.util.List;

public interface SpellDao {
	
	List<Spell> findAllSpells();

	Spell findSpellByNom(final String nom);
}



