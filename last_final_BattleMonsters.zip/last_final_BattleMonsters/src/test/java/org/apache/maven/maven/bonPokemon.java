package org.apache.maven.maven;

import euromillionCsv.Tirage;
import pokemonCsv.SimplePokemon;
import spellsCsv.Spell;
import start.BeginPokeChoice;

import java.io.File;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class bonPokemon {
	
	 public int date;
	 boolean flag=false;
		 
	//POKEMON
	final static String FILE_NAME = "src/main/resources/pokemon.csv";
	final static File FILE = new File(FILE_NAME);
	
	//TIRAGE
	final static String FILE_NAME2 = "src/main/resources/euromillions_4.csv";
	final static File FILE2 = new File(FILE_NAME2);
	
	//ATTAQUE
	final static String FILE_NAME3 = "src/main/resources/spells.csv";
	final static File FILE3 = new File(FILE_NAME3);
		
		
		//--------------DEBUT TEST-------------------//
	
	@Before
	public void doBefore() {
        System.out.println("doBefore Debut");
        //date = "11/03/2016";
        date = 1;
        System.out.println("doBefore Fin");
    }
	
	@Test
	public void test() {
		
		//Notre tirage 11/03/2016 : 26, 43, 1, 21, 40   9   6
		
		 //Ce que l'on veut :
        //
		final int num1 = 26;
		final int num2 = 43;
		final int num3 = 1;
		final int num4 = 21;
		final int num5 = 40;
		final int stars1 = 9;
		final int stars2 = 6;
		
		//Attaques pokemon 1
		final int s1 = 35;
		final int s2 = 2;
		final int s3 = 10;
		final int s4 = 30;
		final int s5 = 49;
		//Attaque pokemon 2
		final int a1 = 32;
		final int a2 = 49;
		final int a3 = 7;
		final int a4 = 27;
		final int a5 = 46;
		
		System.out.println("testTirage... Debut");

       
		//Debut du test:
				//
				
				//Récupération chiffre pour les attaques:
        Tirage euro = BeginPokeChoice.doFindAdvancedEuro(date);
		int p1 = euro.getStarOne();
		int p2 = euro.getStarTwo();
		int n1 = euro.getnOne();
		int n2 = euro.getnTwo();
		int n3 = euro.getnThree();
		int n4 = euro.getnFour();
		int n5 = euro.getnFive();
		
		
        Assert.assertEquals(num1, n1);
        Assert.assertEquals(num2, n2);
        Assert.assertEquals(num3, n3);
        Assert.assertEquals(num4, n4);
        Assert.assertEquals(num5, n5);
        
        //Récupération Pokemon
		//Pokemon 1
        Assert.assertEquals(stars1, p1);
        final SimplePokemon monster1 = (SimplePokemon) BeginPokeChoice.doFindAdvanced(p1);
        //Pokemon 2
        Assert.assertEquals(stars2, p2);
        final SimplePokemon monster2 = (SimplePokemon) BeginPokeChoice.doFindAdvanced(p2);
        
        //Sorts Pokemon 1:
        int sort1 = num1 + p1; 	if(sort1 > 50){ sort1 = sort1-50;}
		int sort2 = num2 + p1; 	if(sort2 > 50){ sort2 = sort2-50;}
		int sort3 = num3 + p1; 	if(sort3 > 50){ sort3 = sort3-50;}
		int sort4 = num4 + p1; 	if(sort4 > 50){ sort4 = sort4-50;}
		int sort5 = num5 + p1; 	if(sort5 > 50){ sort5 = sort5-50;}
		
		//Sorts Pokemon 2:
        int sort6 = num1 + p2; 	if(sort6 > 50){ sort6 = sort6-50;}
		int sort7 = num2 + p2; 	if(sort7 > 50){ sort7 = sort7-50;}
		int sort8 = num3 + p2; 	if(sort8 > 50){ sort8 = sort8-50;}
		int sort9 = num4 + p2; 	if(sort9 > 50){ sort9 = sort9-50;}
		int sort10 = num5 + p2; if(sort10 > 50){ sort10 = sort10-50;}
		
		
		Spell spell1= BeginPokeChoice.doFindSpells(sort1);
		monster1.setSpell1(spell1);
		Spell spell2= BeginPokeChoice.doFindSpells(sort2);
		monster1.setSpell2(spell2);
		Spell spell3= BeginPokeChoice.doFindSpells(sort3);
		monster1.setSpell3(spell3);
		Spell spell4= BeginPokeChoice.doFindSpells(sort4);
		monster1.setSpell4(spell4);
		Spell spell5= BeginPokeChoice.doFindSpells(sort5);
		monster1.setSpell5(spell5);
		
		
		Spell spell6= BeginPokeChoice.doFindSpells(sort6);
		monster2.setSpell1(spell6);
		Spell spell7= BeginPokeChoice.doFindSpells(sort7);
		monster2.setSpell2(spell7);
		Spell spell8= BeginPokeChoice.doFindSpells(sort8);
		monster2.setSpell3(spell8);
		Spell spell9= BeginPokeChoice.doFindSpells(sort9);
		monster2.setSpell4(spell9);
		Spell spell10= BeginPokeChoice.doFindSpells(sort10);
		monster2.setSpell5(spell10);
		
		
// ------------------ TESTS DES BONS SPELLS------------------------//
	
		String m1 = BeginPokeChoice.doFindSpells(s1).toString();
		String x1 = monster1.getSpell1().toString();
		
		String m2 = BeginPokeChoice.doFindSpells(s2).toString();
		String x2 = monster1.getSpell2().toString();
		
		String m3 = BeginPokeChoice.doFindSpells(s3).toString();
		String x3 = monster1.getSpell3().toString();
		
		String m4 = BeginPokeChoice.doFindSpells(s4).toString();
		String x4 = monster1.getSpell4().toString();
		
		String m5 = BeginPokeChoice.doFindSpells(s5).toString();
		String x5 = monster1.getSpell5().toString();

		String m6 = BeginPokeChoice.doFindSpells(a1).toString();
		String x6 = monster2.getSpell1().toString();

		String m7 = BeginPokeChoice.doFindSpells(a2).toString();
		String x7 = monster2.getSpell2().toString();
		
		String m8 = BeginPokeChoice.doFindSpells(a3).toString();
		String x8 = monster2.getSpell3().toString();
		
		String m9 = BeginPokeChoice.doFindSpells(a4).toString();
		String x9 = monster2.getSpell4().toString();
		
		String m10 = BeginPokeChoice.doFindSpells(a5).toString();
		String x10 = monster2.getSpell5().toString();
		

		if(m1.equals(x1) && 
				m2.equals(x2) &&
				m3.equals(x3) && 
				m4.equals(x4) && 
				m5.equals(x5) &&
				m6.equals(x6) &&
				m7.equals(x7) &&
				m8.equals(x8) &&
				m9.equals(x9) &&
				m10.equals(x10)
				){
			flag = true;
		}
		Assert.assertEquals(true, flag);
		
		
        System.out.println("testTirage... Fin");
		
	}
}
