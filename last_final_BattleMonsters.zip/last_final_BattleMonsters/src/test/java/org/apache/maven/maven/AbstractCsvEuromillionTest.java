package org.apache.maven.maven;

import org.apache.log4j.Logger;

import euromillionCsv.AbstractCsvEuromillion;
import euromillionCsv.SimpleTirage;
import euromillionCsv.Tirage;

import java.io.File;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public abstract class AbstractCsvEuromillionTest {
	 private static final Logger LOGGER = Logger.getLogger(AbstractCsvEuromillionTest.class);
	 
	 private final static String RESOURCES_PATH = "src/main/resources/";
	 private final static String EURO_FILE_NAME = "euromillions_4.csv";
	 
	 protected SimpleTirage dao;
	 
	 @Before
	    public void doBefore() {
	        LOGGER.debug("doBefore Debut");

	        final File file = new File(RESOURCES_PATH + EURO_FILE_NAME);
	        dao.setnFive(5);

	        LOGGER.debug("doBefore Fin");
	    }
	 
	 	/**
	     * Teste le nombre de tirages trouves.
	     * 
	     * RESULT Nombre tirage : 5
	     */
	    @Test
	    public void testCinqTirage() {
	        LOGGER.debug("testCinqTirage... Debut");

	        // Arrange
	        final int nombreTirageAttendus = 5;

	        // Act
	        final int tirage = dao.getnFive();

	        // Assert
	        Assert.assertEquals(nombreTirageAttendus, tirage);

	        LOGGER.debug("testCinqTirage... Fin");
	    }
}
