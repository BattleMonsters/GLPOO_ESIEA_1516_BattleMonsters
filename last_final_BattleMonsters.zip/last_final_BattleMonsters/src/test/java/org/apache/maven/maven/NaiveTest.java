package org.apache.maven.maven;
    
import org.apache.maven.maven.AbstractCsvEuromillionTest;

import euromillionCsv.SimpleTirage;

public class NaiveTest extends AbstractCsvEuromillionTest {
	public NaiveTest() {
        dao = new SimpleTirage();
    }
}
