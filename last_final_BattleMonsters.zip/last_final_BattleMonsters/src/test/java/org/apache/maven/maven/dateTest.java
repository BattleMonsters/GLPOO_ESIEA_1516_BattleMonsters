package org.apache.maven.maven;

import java.io.File;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import euromillionCsv.Tirage;
import start.DefineTirage;
import start.BeginPokeChoice;

public class dateTest {
		
	final static String FILE_NAME = "src/main/resources/euromillions_4.csv";
	final static File FILE = new File(FILE_NAME);
	
		static DefineTirage define = DefineTirage.tirage;
		String dateVoulu;
		String date1;
		int nb;
		
		@Before
		public void doBefore() {
			nb = 3;
		}
		
		@Test
		public void test() throws InterruptedException {
			dateVoulu = "04/03/2016";
			Tirage euro = BeginPokeChoice.doFindAdvancedEuro(nb);
			date1 = euro.getDate();
			
			Assert.assertEquals(dateVoulu, date1);
		}


}