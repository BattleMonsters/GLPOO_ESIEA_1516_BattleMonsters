package org.apache.maven.maven;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import pokemonCsv.Pokemon;
import pokemonCsv.SimplePokemon;
import start.BeginPokeChoice;
import start.Combat;

public class CombatTest {
	
	public Pokemon[] listOrder;
	public boolean victory;
	public Combat combat;
	
	//------------------------------FONCTIONS A TESTER--------------//
	public static Pokemon setPlayers(Pokemon poke, int player){
		
		final SimplePokemon monster = (SimplePokemon) poke;

		monster.setDresseur(player);
	
		return monster;

	}
	
	///---Trie la liste en fonction de la vitesse des pokemons, le plus rapide attaquera en 1er---//
		private Pokemon[] getSpeed(Pokemon j1m1, Pokemon j1m2, Pokemon j2m1, Pokemon j2m2){
			int j1m1speed = j1m1.getSpeed();
			int j1m2speed = j1m2.getSpeed();
			int j2m1speed = j2m1.getSpeed();
			int j2m2speed = j2m2.getSpeed();
			
			Pokemon[] fightOrder = {j1m1,j1m2,j2m1,j2m2};
			int[] list = {j1m1speed,j1m2speed,j2m1speed,j2m2speed};
			Arrays.sort(list);
			list = swap(0,3,list);
			list = swap(1,2,list);
			
			Pokemon[] trieOrder = new Pokemon[4];
			int j=0;
			int i=0;
			while(j<4){
				for(i = 0; i<4; i++){
					if(list[j]==fightOrder[i].getSpeed()){
						trieOrder[j]=fightOrder[i];
					}
				}
				i=0;
				j++;
			}
		return trieOrder;
		}
		
		
		private int[] swap(int i, int j, int[] list) {
			int temp;
			temp = list[i];
			list[i]=list[j];
			list[j]=temp;
			
			return list;
		}
		
		

	//--------------------------------TEST Tri des 4 pokemons par leur vitesse ----------------------------------------------//
	
	Pokemon j1m1;
	Pokemon j1m2;
	Pokemon j2m1;
	Pokemon j2m2;
	
	@Before
	public void doBefore() {
        System.out.println("doBefore Debut");
        
        //date1 = "04/03/2016";
        int date1 = 3;
        //9	 23	40	16	14	   1	5
		//date2 = "01/03/2016";
		int date2 = 4;
		//37 7	28	13	4	   11	10

		j1m1 = BeginPokeChoice.getFirst(date1);
		j1m2 = BeginPokeChoice.getSecond(date1);
	
		j2m1 = BeginPokeChoice.getFirst(date2);
		j2m2 = BeginPokeChoice.getSecond(date2);
		
		j1m1 = setPlayers(j1m1,1);
		j1m2 = setPlayers(j1m2,1);

		j2m1 = setPlayers(j2m1,2);
		j2m2 = setPlayers(j2m2,2);

        System.out.println("doBefore Fin");
    }
	
	boolean flag = false;
	private Pokemon[] listVoulus = new Pokemon[4];
	@Test
	public void test() {
		
		System.out.println("Test 1 Debut");
		
		//Num: POKEMON 1 POKEMON 2 POKEMON 3 POKEMON 4 
		//       j1m1      j1m2      j2m1      j2m2
		//Vit:    15 		16		  25		14
		
		//Liste  voulu:
		listVoulus[0] = j2m1;
		listVoulus[1] = j1m2;
		listVoulus[2] = j1m1;
		listVoulus[3] = j2m2;
		
		//Liste triée:
		listOrder = getSpeed(j1m1,j1m2,j2m1,j2m2);
		
		if((listVoulus[0].toString().equals(listOrder[0].toString())) && 
				(listVoulus[1].toString().equals(listOrder[1].toString())) && 
				(listVoulus[2].toString().equals(listOrder[2].toString())) && 
				(listVoulus[3].toString().equals(listOrder[3].toString()))) {
			flag = true;
		}
		Assert.assertEquals(true, flag);
		
		System.out.println("Test 1 Fin");	
		
	}
}
